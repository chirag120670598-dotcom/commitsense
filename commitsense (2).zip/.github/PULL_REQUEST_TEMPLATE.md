---
name: 🚀 Pull Request
about: Contribute code, docs, or tests to CommitSense
title: "[PR]: "
labels: ["pr-needs-review"]
assignees: []
---

## What does this change?

A clear, concise description of what this PR does. Link any related issues.

Closes #

## Type of change

- [ ] 🐛 Bug fix (non-breaking change that fixes an issue)
- [ ] ✨ New feature (non-breaking change that adds functionality)
- [ ] 💥 Breaking change (fix or feature that would change existing behavior)
- [ ] 📝 Documentation (README, docs, comments)
- [ ] 🧪 Tests only (no production code changes)

## How was this tested?

Describe the tests you ran:

```bash
# Commands run
pytest tests/
ruff check commitsense/
```

- [ ] All 63 existing tests still pass
- [ ] Added new tests for my change
- [ ] Lint passes (`ruff check`)
- [ ] Manually verified the CLI works

## Checklist

- [ ] My code follows the project's style (see `CONTRIBUTING.md`)
- [ ] I have added docstrings + type hints for new functions
- [ ] I have updated the CHANGELOG.md (under "Unreleased")
- [ ] I have added tests that prove my fix/feature works
- [ ] New and existing unit tests pass locally
- [ ] I have updated relevant documentation

## Screenshots / Demo

If applicable, add screenshots or a GIF showing the change in action.
