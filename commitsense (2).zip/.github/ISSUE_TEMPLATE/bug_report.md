---
name: 🐛 Bug report
about: Something isn't working correctly
title: "[Bug]: "
labels: ["bug", "needs-triage"]
assignees: []
---

## Describe the bug

A clear and concise description of what the bug is.

## To reproduce

```bash
# Exact commands that triggered the bug
```

## Expected behavior

What you expected to happen.

## Actual behavior

What actually happened. Include the **full terminal output** and stack trace if any.

## Environment

- **CommitSense version:** (run `commitsense --version`)
- **Python version:** (run `python --version`)
- **OS:** (e.g., macOS 14.2, Ubuntu 24.04, Windows 11)
- **Ollama version:** (run `ollama --version`)
- **Model used:** (e.g., llama3.2, mistral, codellama)

## Screenshots / Logs

If applicable, add screenshots or paste logs here.

## Checklist

- [ ] I have searched [existing issues](https://github.com/yourname/commitsense/issues) to make sure this isn't a duplicate
- [ ] I can reproduce this on the latest release
- [ ] I have attached relevant logs
