---
name: ✨ Feature request
about: Suggest an idea for CommitSense
title: "[Feature]: "
labels: ["enhancement", "needs-triage"]
assignees: []
---

## Problem

What problem does this solve? What's the use case?

Example: "I'm always frustrated when [...]"

## Proposed solution

Describe what you want to happen. Be as specific as possible — flag names, config keys, code examples.

```bash
# Example CLI usage
commitsense --new-flag value
```

## Alternatives considered

Any other approaches you considered or workarounds you've tried.

## Additional context

Screenshots, mockups, links to similar features in other tools.

## Priority

- [ ] Critical (blocks me from using the tool)
- [ ] High (would significantly improve my workflow)
- [ ] Medium (nice to have)
- [ ] Low (just an idea)
