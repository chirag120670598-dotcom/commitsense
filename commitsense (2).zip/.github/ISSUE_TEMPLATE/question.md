---
name: ❓ Question / Help
about: Need help using CommitSense?
title: "[Question]: "
labels: ["question"]
assignees: []
---

## What are you trying to do?

Describe your goal in 1-2 sentences.

## What have you tried?

Show the commands you ran and what happened.

## Environment

- CommitSense version:
- OS:
- Ollama model:

## Relevant docs

- [README](https://github.com/yourname/commitsense#readme)
- [Troubleshooting](https://github.com/yourname/commitsense/blob/main/CONTRIBUTING.md)
