# 🎬 Demo GIF

Drop your terminal recording here as `demo.gif` (≤ 5 MB).

Recommended recording tool:
- **macOS**: `brew install kap && kap`
- **Linux**: `peek` or `recordmydesktop`
- **Windows**: ScreenToGif

Suggested capture flow (≈ 20 seconds):
1. `cd /tmp && mkdir demo-repo && cd demo-repo && git init`
2. `printf "print('hi')" > app.py && git add .`
3. `commitsense` → wait for menu
4. Pick "Commit with this message"
5. `git log --oneline` — show the perfect conventional commit

Then commit the gif:
```bash
git add docs/demo.gif
git commit -m "docs: add demo recording"
```