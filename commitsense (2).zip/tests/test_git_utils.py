"""Tests for git_utils helpers that don't need a real git repo."""

from __future__ import annotations

from commitsense.git_utils import (
    _parse_changed_files,
    smart_truncate_diff,
)


class TestParseChangedFiles:
    def test_extracts_single_file(self) -> None:
        diff = (
            "diff --git a/foo.py b/foo.py\n"
            "index 1234..5678 100644\n"
            "--- a/foo.py\n"
            "+++ b/foo.py\n"
            "@@ -1 +1 @@\n"
            "-old\n+new\n"
        )
        assert _parse_changed_files(diff) == ["foo.py"]

    def test_extracts_multiple_files(self) -> None:
        diff = (
            "diff --git a/foo.py b/foo.py\n"
            "index 1234..5678 100644\n"
            "diff --git a/bar.py b/bar.py\n"
            "index 1234..5678 100644\n"
        )
        assert _parse_changed_files(diff) == ["foo.py", "bar.py"]

    def test_uses_b_path(self) -> None:
        diff = "diff --git a/old_name.py b/new_name.py\n"
        assert _parse_changed_files(diff) == ["new_name.py"]


class TestSmartTruncateDiff:
    def test_no_truncation_when_small(self) -> None:
        diff = "diff --git a/foo.py b/foo.py\n+x = 1\n"
        assert smart_truncate_diff(diff, max_chars=10000) == diff

    def test_truncates_huge_diff(self) -> None:
        # Build a diff that's much larger than max_chars
        lines = ["diff --git a/big.py b/big.py"]
        for i in range(2000):
            lines.append(f"+line_{i}_content")
        diff = "\n".join(lines)
        out = smart_truncate_diff(diff, max_chars=2000)
        assert len(out) <= 2200  # some slack for the marker
        assert "truncated" in out.lower() or "elided" in out.lower()

    def test_keeps_all_file_headers(self) -> None:
        lines = ["diff --git a/a.py b/a.py"]
        lines.extend([f"+x_{i}" for i in range(500)])
        lines.append("diff --git a/b.py b/b.py")
        lines.extend([f"+y_{i}" for i in range(500)])
        diff = "\n".join(lines)
        out = smart_truncate_diff(diff, max_chars=1500)
        assert "diff --git a/a.py" in out
        assert "diff --git a/b.py" in out
