"""Tests for commitsense.ai_engine with mocked HTTP."""

from __future__ import annotations

import json

import pytest
import responses

from commitsense import ai_engine
from commitsense.ai_engine import (
    OllamaInvalidResponse,
    OllamaModelMissing,
    OllamaUnavailable,
    _extract_json,
    generate,
)


class TestExtractJson:
    def test_direct_json(self) -> None:
        assert _extract_json('{"a": 1}') == {"a": 1}

    def test_json_in_fence(self) -> None:
        assert _extract_json('```json\n{"a": 1}\n```') == {"a": 1}

    def test_json_in_plain_fence(self) -> None:
        assert _extract_json('```\n{"a": 1}\n```') == {"a": 1}

    def test_json_embedded_in_text(self) -> None:
        text = 'Some preamble {"a": 1, "b": 2} trailing text'
        assert _extract_json(text) == {"a": 1, "b": 2}

    def test_invalid_returns_none(self) -> None:
        assert _extract_json("not json at all") is None

    def test_non_object_returns_none(self) -> None:
        assert _extract_json("[1, 2, 3]") is None


class TestGenerate:
    @responses.activate
    def test_happy_path(self, sample_diff: str) -> None:
        responses.add(
            responses.GET,
            "http://localhost:11434/",
            json={"status": "ok"},
            status=200,
        )
        responses.add(
            responses.POST,
            "http://localhost:11434/api/generate",
            json={
                "response": json.dumps({
                    "commit_message": "feat(auth): add oauth",
                    "pr_title": "Add OAuth",
                    "pr_description": "## What changed\nOAuth",
                })
            },
            status=200,
        )

        result = generate(diff=sample_diff, model="llama3", language="english", use_cache=False)
        assert result["commit_message"] == "feat(auth): add oauth"
        assert result["pr_title"] == "Add OAuth"
        assert "What changed" in result["pr_description"]

    @responses.activate
    def test_ollama_down_raises_unavailable(self, sample_diff: str) -> None:
        # Health check fails -> OllamaUnavailable raised
        with pytest.raises(OllamaUnavailable):
            generate(diff=sample_diff, use_cache=False)

    @responses.activate
    def test_model_missing_404(self, sample_diff: str) -> None:
        responses.add(responses.GET, "http://localhost:11434/", json={"ok": True}, status=200)
        responses.add(
            responses.POST,
            "http://localhost:11434/api/generate",
            json={"error": "model not found"},
            status=404,
        )
        with pytest.raises(OllamaModelMissing):
            generate(diff=sample_diff, use_cache=False)

    @responses.activate
    def test_invalid_response_recovers(self, sample_diff: str) -> None:
        """Even on garbage from Ollama, generate returns a sensible fallback."""
        responses.add(responses.GET, "http://localhost:11434/", json={"ok": True}, status=200)
        # First call returns garbage; retry also returns garbage; fallback kicks in
        responses.add(
            responses.POST,
            "http://localhost:11434/api/generate",
            json={"response": "definitely not json at all sorry"},
            status=200,
        )
        responses.add(
            responses.POST,
            "http://localhost:11434/api/generate",
            json={"response": "still not json"},
            status=200,
        )

        result = generate(diff=sample_diff, use_cache=False)
        # Fallback uses the raw first line
        assert result["commit_message"] == "definitely not json at all sorry"


class TestFriendlyError:
    def test_unavailable(self) -> None:
        msg = ai_engine.friendly_error(OllamaUnavailable("nope"))
        assert "ollama serve" in msg.lower()

    def test_model_missing(self) -> None:
        msg = ai_engine.friendly_error(OllamaModelMissing("missing"))
        assert "missing" in msg

    def test_invalid_response(self) -> None:
        msg = ai_engine.friendly_error(OllamaInvalidResponse("bad"))
        assert "json" in msg.lower()
