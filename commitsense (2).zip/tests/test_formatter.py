"""Tests for commitsense.formatter."""

from __future__ import annotations

import pytest

from commitsense.formatter import (
    ALLOWED_TYPES,
    detect_scope,
    enforce_conventional,
    lint_message,
    parse_message,
)


class TestEnforceConventional:
    """Test the main conventional-commits enforcement entry point."""

    @pytest.mark.parametrize(
        "raw,files,expected",
        [
            ("feat(auth): add oauth login", None, "feat(auth): add oauth login"),
            ("Added login button", ["src/auth/ui.py"], "feat(auth): added login button"),
            ("FIX: bug in payment flow", ["src/payments/processor.py"], "fix(payments): bug in payment flow"),
            ("Update docs for installation", ["README.md"], "docs(readme): update docs for installation"),
            ("feat: clean up db connection pooling", ["src/api/db.py"], "feat(api): clean up db connection pooling"),
        ],
    )
    def test_basic_enforcement(self, raw: str, files, expected: str) -> None:
        assert enforce_conventional(raw, files) == expected

    def test_strips_quotes(self) -> None:
        assert enforce_conventional('"feat: hello"', None) == "feat: hello"

    def test_lowercases_description(self) -> None:
        assert enforce_conventional("feat: ADD A THING", None) == "feat: add a thing"

    def test_strips_trailing_period(self) -> None:
        assert enforce_conventional("feat: do the thing.", None) == "feat: do the thing"

    def test_truncates_long_descriptions(self) -> None:
        long = "feat: " + ("a" * 100)
        out = enforce_conventional(long, None)
        # Header can be up to 100 chars per Conventional Commits;
        # description portion is clamped to 72 chars + ellipsis.
        header = out.split("\n")[0]
        assert len(header) <= 100
        assert "…" in header or len(header) < 100

    def test_preserves_breaking_bang(self) -> None:
        out = enforce_conventional("feat(api)!: rewrite auth flow", None)
        assert out.startswith("feat(api)!:")
        assert "rewrite auth flow" in out

    def test_preserves_breaking_footer(self) -> None:
        raw = (
            "feat(api): change response shape\n\n"
            "BREAKING CHANGE: response is now JSON:API compliant"
        )
        out = enforce_conventional(raw, None)
        # Either form is acceptable: "feat(api)!:" header OR
        # "feat(api):" with explicit BREAKING CHANGE footer.
        assert ("feat(api)!:" in out) or ("feat(api):" in out)
        assert "BREAKING CHANGE: response is now JSON:API compliant" in out

    def test_empty_message_falls_back(self) -> None:
        assert enforce_conventional("", None) == "chore: update"
        assert enforce_conventional(None, None) == "chore: update"  # type: ignore[arg-type]

    def test_infers_refactor(self) -> None:
        assert enforce_conventional("refactored the auth module", ["src/auth/x.py"]).startswith("refactor(auth):")

    def test_infers_perf(self) -> None:
        assert enforce_conventional("optimise database queries", ["src/db.py"]).startswith("perf(db):")

    def test_preserves_body(self) -> None:
        raw = "feat: hello\n\nThis is the body.\nIt spans multiple lines."
        out = enforce_conventional(raw, None)
        assert "This is the body." in out
        assert "It spans multiple lines." in out


class TestDetectScope:
    def test_common_top_dir(self) -> None:
        assert detect_scope(["src/auth/login.py", "src/auth/oauth.py"]) == "auth"

    def test_single_file(self) -> None:
        assert detect_scope(["README.md"]) == "readme"

    def test_no_files(self) -> None:
        assert detect_scope([]) is None

    def test_strips_src_wrapper(self) -> None:
        assert detect_scope(["src/api/server.py", "src/api/router.py"]) == "api"

    def test_sanitises_special_chars(self) -> None:
        # dots and slashes get stripped during scope sanitisation
        result = detect_scope(["pkg.with.dots/file.py"])
        assert result is not None
        assert "/" not in result
        assert "." not in result


class TestLintMessage:
    def test_clean_message_has_no_issues(self) -> None:
        assert lint_message("feat(auth): add oauth login") == []

    def test_empty_message(self) -> None:
        issues = lint_message("")
        assert any("empty" in i.lower() for i in issues)

    def test_unknown_type_flagged(self) -> None:
        issues = lint_message("wibble: do a thing")
        assert any("unknown type" in i for i in issues)

    def test_capitalised_description_warned(self) -> None:
        issues = lint_message("feat: Add a thing")
        assert any("lowercase" in i for i in issues)

    def test_trailing_period_warned(self) -> None:
        issues = lint_message("feat: do the thing.")
        assert any("period" in i for i in issues)

    def test_long_header_warned(self) -> None:
        long = "feat: " + "a" * 200
        issues = lint_message(long)
        assert any("header line" in i for i in issues)

    def test_all_allowed_types_accepted(self) -> None:
        for t in ALLOWED_TYPES:
            issues = lint_message(f"{t}: do thing")
            assert not any("unknown type" in i for i in issues), f"{t} should be allowed"


class TestParseMessage:
    def test_parses_header(self) -> None:
        ctype, scope, breaking, desc, body, footers = parse_message("feat(auth)!: hello")
        assert ctype == "feat"
        assert scope == "auth"
        assert breaking is True
        assert desc == "hello"
        assert body == []
        assert footers == []

    def test_parses_breaking_footer(self) -> None:
        raw = "feat: hello\n\nBREAKING CHANGE: removed foo"
        ctype, _scope, breaking, _desc, _body, footers = parse_message(raw)
        assert breaking is True
        assert any("BREAKING CHANGE" in f for f in footers)
