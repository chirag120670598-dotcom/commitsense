"""End-to-end CLI tests via Click's CliRunner."""

from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from commitsense.main import main as cli


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


def test_help_exits_zero(runner: CliRunner) -> None:
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "CommitSense" in result.output


def test_version(runner: CliRunner) -> None:
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == 0
    assert "commitsense" in result.output.lower()


def test_check_clean_message(runner: CliRunner) -> None:
    result = runner.invoke(cli, ["--check", "feat(auth): add oauth"])
    assert result.exit_code == 0
    assert "compliant" in result.output.lower()


def test_check_bad_message_exits_1(runner: CliRunner) -> None:
    result = runner.invoke(cli, ["--check", "wibble: do thing"])
    assert result.exit_code == 1
    assert "unknown type" in result.output


def test_clear_cache(runner: CliRunner) -> None:
    result = runner.invoke(cli, ["--clear-cache"])
    assert result.exit_code == 0
    assert "cache" in result.output.lower()


def test_no_color_strips_ansi(runner: CliRunner) -> None:
    result = runner.invoke(cli, ["--check", "feat: thing", "--no-color"])
    assert result.exit_code == 0
    # ANSI escape starts with \x1b[
    assert "\x1b[" not in result.output


def test_outside_git_repo_errors_friendly(runner: CliRunner, tmp_path) -> None:
    with patch("commitsense.main.is_git_repo", return_value=False):
        result = runner.invoke(cli, [])
    assert result.exit_code == 1
    assert "git repository" in result.output
