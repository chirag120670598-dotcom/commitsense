"""Shared pytest fixtures.

These tests are pure-Python — they never touch the network, never spawn
a real git command, and never touch the user's real ``~/.commitsense``
directory. Every test is hermetic.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest


@pytest.fixture(autouse=True)
def isolated_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect ``~/.commitsense`` to a tmp dir for every test."""
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))

    # Make sure the package under test is importable
    pkg_root = Path(__file__).resolve().parent.parent
    if str(pkg_root) not in sys.path:
        sys.path.insert(0, str(pkg_root))

    # Modules capture CONFIG_DIR at import time — re-point them at tmp
    from commitsense import cache, config

    config.CONFIG_DIR = tmp_path / ".commitsense"
    config.CONFIG_FILE = config.CONFIG_DIR / "config.json"
    cache.CONFIG_DIR = config.CONFIG_DIR
    cache.CACHE_FILE = config.CONFIG_DIR / "cache.json"

    return tmp_path


@pytest.fixture
def sample_diff() -> str:
    """A realistic-looking diff used in many tests."""
    return (
        "diff --git a/src/auth/login.py b/src/auth/login.py\n"
        "index 1234567..89abcde 100644\n"
        "--- a/src/auth/login.py\n"
        "+++ b/src/auth/login.py\n"
        "@@ -1,3 +1,15 @@\n"
        "+def google_oauth_login(user):\n"
        "+    token = get_token_from_google()\n"
        "+    user.token = token\n"
        "+    user.save()\n"
        "+def refresh_oauth_token(user):\n"
        "+    ...\n"
    )


@pytest.fixture
def staged_diff_response() -> str:
    """Mock raw JSON returned by Ollama."""
    return (
        '{"commit_message": "feat(auth): add google oauth login with token refresh", '
        '"pr_title": "Add Google OAuth login", '
        '"pr_description": "## What changed\\nAdded OAuth.\\n\\n## Why\\nFor login.\\n\\n'
        '## How to test\\nClick login."}'
    )
