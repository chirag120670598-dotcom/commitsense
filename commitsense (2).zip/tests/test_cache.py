"""Tests for commitsense.cache."""

from __future__ import annotations

from commitsense import cache


def test_make_key_is_deterministic() -> None:
    a = cache.make_key("diff", "llama3", "english")
    b = cache.make_key("diff", "llama3", "english")
    assert a == b


def test_make_key_changes_with_inputs() -> None:
    a = cache.make_key("diff", "llama3", "english")
    b = cache.make_key("diff", "mistral", "english")
    c = cache.make_key("different diff", "llama3", "english")
    assert a != b
    assert a != c


def test_roundtrip(tmp_path) -> None:
    key = cache.make_key("some diff", "llama3", "english")
    payload = {"commit_message": "feat: hello", "pr_title": "x", "pr_description": "y"}

    assert cache.get(key) is None
    cache.set_(key, payload)
    assert cache.get(key) == payload


def test_clear_removes_entries(tmp_path) -> None:
    key = cache.make_key("another diff", "llama3", "english")
    cache.set_(key, {"commit_message": "x"})
    assert cache.clear() >= 1
    assert cache.get(key) is None
