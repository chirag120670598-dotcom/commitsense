"""Tests for commitsense.config."""

from __future__ import annotations

import json
from pathlib import Path

from commitsense import config


def test_load_creates_defaults(tmp_path: Path) -> None:
    cfg = config.load_config()
    assert cfg["model"] == "llama3"
    assert cfg["language"] == "english"
    assert cfg["commit_style"] == "conventional"
    # File should now exist
    assert config.CONFIG_FILE.exists()


def test_save_and_reload(tmp_path: Path) -> None:
    cfg = config.load_config()
    cfg["model"] = "mistral"
    cfg["language"] = "hindi"
    config.save_config(cfg)

    cfg2 = config.load_config()
    assert cfg2["model"] == "mistral"
    assert cfg2["language"] == "hindi"


def test_corrupt_config_resets(tmp_path: Path) -> None:
    # Pre-create a corrupt file
    config.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    config.CONFIG_FILE.write_text("not valid json {", encoding="utf-8")

    cfg = config.load_config()
    assert cfg["model"] == "llama3"  # fell back to defaults


def test_missing_keys_filled_with_defaults(tmp_path: Path) -> None:
    config.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    config.CONFIG_FILE.write_text(json.dumps({"model": "phi3"}), encoding="utf-8")

    cfg = config.load_config()
    assert cfg["model"] == "phi3"
    assert cfg["language"] == "english"  # filled from defaults
    assert cfg["commit_style"] == "conventional"  # filled from defaults
