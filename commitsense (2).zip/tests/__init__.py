"""Pytest suite for CommitSense."""
