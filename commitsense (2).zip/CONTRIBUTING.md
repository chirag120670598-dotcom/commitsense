# Contributing to CommitSense

First off — thanks for taking the time to contribute! 🧠💚

## Quick start

```bash
git clone https://github.com/<your-username>/commitsense.git
cd commitsense
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev,test]"
```

## Running tests

```bash
pytest                       # full suite with coverage
pytest tests/test_formatter.py  # single module
pytest -k conventional       # by keyword
ruff check commitsense tests # lint
mypy commitsense             # type-check
```

## Pull-request checklist

- [ ] Tests pass locally (`pytest`)
- [ ] Linter is clean (`ruff check`)
- [ ] New public functions have **docstrings** and **type hints**
- [ ] No raw `print()` — use `click.echo()` or the helpers in `main.py`
- [ ] Updated `CHANGELOG.md` under "Unreleased"
- [ ] Commit message follows Conventional Commits (use `commitsense` itself 😉)

## Good first issues

- 🟢 Add a `--no-cache` flag to bypass the response cache
- 🟢 Support more Ollama endpoints (custom `--host` / `--port`)
- 🟢 Add support for `git commit -m-` (stdin) message linting
- 🟢 Add an `analyze` subcommand that just summarises the diff without committing
- 🟢 Windows path handling in `formatter.detect_scope`
- 🟢 Add a `--max-diff-size` flag with custom truncation strategy

## Commit message style

We dogfood our own tool — every PR is committed via `commitsense`:

```bash
git add .
commitsense   # pick "Commit with this message" → feat: add amazing thing
```

## Release process

1. Bump version in `pyproject.toml` + `commitsense/__init__.py`
2. Update `CHANGELOG.md` (move Unreleased → dated section)
3. Tag: `git tag -a v1.x.y -m "v1.x.y"`
4. Push: `git push origin main --tags`
5. Build: `python -m build`
6. Publish: `twine upload dist/*`

## Code style

- 100-char line limit (configured in `pyproject.toml`)
- Type hints on every public function
- Docstrings on every public function (Google style)
- Prefer explicit imports over star imports
- Pure functions where possible (easier to test)

Thanks again — let's make commits great again. 🚀