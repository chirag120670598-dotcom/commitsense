# Changelog

All notable changes to CommitSense are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [1.1.0] - 2024-XX-XX

### Added
- ⚡ **Disk-based response cache** — repeated diffs hit cache, no Ollama call
- 📊 **Diff stats** in summary (`+12 −4 in 3 files`)
- 🧠 **Breaking change detection** — `BREAKING CHANGE:` footer or `!` suffix auto-applied
- 🦶 **Footer extraction** — `Closes #123`, `Refs: …` preserved into commit message
- 🎞️ **Spinner** while Ollama thinks — no more frozen terminal
- ✂️ **Smart diff truncation** — large diffs kept small by trimming repetitive hunks
- 🚀 **New flags**:
  - `--dry-run` — preview without committing
  - `--yes` / `-y` — skip the interactive menu
  - `--amend` — amend the previous commit
  - `--check MSG` — lint an existing message
  - `--no-color` — disable ANSI colours (for piping/CI)
  - `--verbose` / `-v` — show extra debug info
  - `--install-hook` — install as `prepare-commit-msg` git hook
- 🪝 **Git hook installer** — auto-fill commit message in `git commit`
- 🧪 **pytest test suite** — 30+ tests covering formatter, git_utils, config, cache, CLI
- 🤖 **GitHub Actions CI** — runs on every push / PR across Python 3.8–3.13

### Changed
- Faster first run via cached Ollama health checks
- Improved prompt to better elicit JSON from smaller models
- Better Conventional Commits inference for `refactor` / `perf` / `ci`

### Fixed
- Recursion bug in `config.ensure_config_exists` (no longer calls itself)
- Missing `Path` import in `formatter`
- `distutils` issue on Python 3.12+ (`setuptools` now pinned)

## [1.0.0] - 2024-XX-XX

### Added
- Initial public release
- `commitsense` command with full 6-step flow
- Ollama integration with strict-JSON parsing + 1-shot retry
- Conventional Commits enforcement
- Multi-language output (`--lang hindi`, etc.)
- Interactive inquirer menu
- Clipboard copy (`pyperclip`)
- Save PR description to `pr_description.md`
- Interactive config editor (`--config`)
- Pip-installable via `pip install .`