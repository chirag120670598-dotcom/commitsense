"""Disk-based response cache keyed by SHA-256 of the diff.

Repeated runs on the same diff skip the Ollama round-trip entirely.
Cache lives at ``~/.commitsense/cache.json`` and is bounded by size + age.
"""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Dict, Optional

from .config import CONFIG_DIR

CACHE_FILE: Path = CONFIG_DIR / "cache.json"
MAX_ENTRIES = 64
TTL_SECONDS = 7 * 24 * 60 * 60  # 1 week


def _load() -> Dict[str, Dict[str, Any]]:
    """Load the cache file, returning an empty dict on any error."""
    if not CACHE_FILE.exists():
        return {}
    try:
        with open(CACHE_FILE, encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def _save(data: Dict[str, Dict[str, Any]]) -> None:
    """Persist the cache, trimming old + excess entries first."""
    now = time.time()
    # 1. Drop expired
    data = {k: v for k, v in data.items() if now - v.get("ts", 0) < TTL_SECONDS}
    # 2. Bound size — keep most recent MAX_ENTRIES
    if len(data) > MAX_ENTRIES:
        sorted_items = sorted(data.items(), key=lambda kv: kv[1].get("ts", 0), reverse=True)
        data = dict(sorted_items[:MAX_ENTRIES])
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        with open(CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def make_key(diff: str, model: str, language: str) -> str:
    """Build a stable cache key from the inputs that affect the response."""
    h = hashlib.sha256()
    h.update(model.encode("utf-8"))
    h.update(b"\0")
    h.update(language.encode("utf-8"))
    h.update(b"\0")
    h.update(diff.encode("utf-8"))
    return h.hexdigest()[:32]


def get(key: str) -> Optional[Dict[str, Any]]:
    """Return the cached response for ``key`` if present and fresh."""
    data = _load()
    entry = data.get(key)
    if not entry:
        return None
    if time.time() - entry.get("ts", 0) > TTL_SECONDS:
        return None
    return entry.get("payload")


def set_(key: str, payload: Dict[str, Any]) -> None:
    """Store ``payload`` under ``key`` with the current timestamp."""
    data = _load()
    data[key] = {"ts": time.time(), "payload": payload}
    _save(data)


def clear() -> int:
    """Wipe the cache. Returns the number of entries removed."""
    data = _load()
    n = len(data)
    try:
        if CACHE_FILE.exists():
            CACHE_FILE.unlink()
    except OSError:
        pass
    return n
