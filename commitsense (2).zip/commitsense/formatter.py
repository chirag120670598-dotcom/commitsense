"""Conventional Commits formatting and validation.

Ensures commit messages follow the Conventional Commits spec:
``type(scope)!: description`` with optional body and footer.

This module is **pure** — no I/O — so it's trivially testable.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import List, Optional, Tuple

ALLOWED_TYPES = (
    "feat",
    "fix",
    "docs",
    "style",
    "refactor",
    "test",
    "chore",
    "perf",
    "ci",
    "build",
    "revert",
)

# Matches a conventional commit header, with or without scope and breaking !
CONVENTIONAL_RE = re.compile(
    r"^(?P<type>[a-zA-Z]+)(?:\((?P<scope>[^)]+)\))?(?P<bang>!)?:\s*(?P<desc>.+)$"
)

# Footer tokens recognised by the Conventional Commits spec
FOOTER_RE = re.compile(
    r"^(?P<key>[A-Za-z][A-Za-z0-9-]*)(?:\:|\s\#)(?P<value>.*)$"
)
BREAKING_TOKEN_RE = re.compile(r"^BREAKING[ -]CHANGE", re.IGNORECASE)
REF_RE = re.compile(r"(?:Closes|Fixes|Resolves|Refs)\s+#\d+", re.IGNORECASE)

MAX_DESC_LENGTH = 72
MAX_BODY_LINE = 100


def detect_scope(files: List[str]) -> Optional[str]:
    """Guess the conventional-commits scope from changed file paths.

    Heuristics:
        * Use the top-level directory if all files share one.
        * Otherwise use the most common top-level directory.
        * Strip common wrapper dirs (``src``, ``lib``, ``app`` …).
        * Strip file extensions from directory-shaped components.

    Args:
        files: List of changed file paths.

    Returns:
        A sanitised scope string, or ``None`` if it cannot be inferred.
    """
    if not files:
        return None

    top_dirs: List[str] = []
    for path in files:
        clean = path.lstrip("./").lstrip("/")
        if "/" in clean:
            top = clean.split("/", 1)[0]
        else:
            top = Path(path).stem
        # Drop common wrapper directories
        if top in {"src", "lib", "app", "pkg", "internal", "packages"}:
            parts = clean.split("/")
            top = parts[1] if len(parts) > 1 else top
        # If the top level still has an extension (e.g. ``db.py``), strip it
        if "." in top and "/" not in top:
            top = top.rsplit(".", 1)[0]
        top_dirs.append(top)

    if not top_dirs:
        return None

    scope = top_dirs[0] if len(set(top_dirs)) == 1 else max(set(top_dirs), key=top_dirs.count)
    scope = re.sub(r"[^a-zA-Z0-9_-]", "", scope).lower()
    return scope or None


def parse_message(message: str) -> Tuple[str, Optional[str], bool, str, List[str], List[str]]:
    """Split a commit message into its conventional parts.

    Returns:
        Tuple of ``(type, scope, breaking, description, body_lines, footers)``.
    """
    if not message:
        return "chore", None, False, "update", [], []

    lines = message.strip().splitlines()
    header = lines[0].strip() if lines else ""

    match = CONVENTIONAL_RE.match(header)
    if match:
        ctype = (match.group("type") or "").lower()
        scope = match.group("scope")
        breaking = bool(match.group("bang"))
        desc = match.group("desc").strip()
    else:
        ctype = ""
        scope = None
        breaking = False
        desc = header

    # Body = lines after header until first blank-or-footer line
    body: List[str] = []
    footers: List[str] = []
    for line in lines[1:]:
        if BREAKING_TOKEN_RE.match(line.strip()):
            breaking = True
            footers.append(line.strip())
            continue
        if FOOTER_RE.match(line.strip()) and not line.startswith(" "):
            footers.append(line.strip())
            continue
        body.append(line.rstrip())

    # Trim trailing empty body lines
    while body and not body[-1].strip():
        body.pop()

    return ctype, scope, breaking, desc, body, footers


def enforce_conventional(
    message: str,
    files: Optional[List[str]] = None,
) -> str:
    """Reformat ``message`` to comply with Conventional Commits.

    If the message already follows the format, it is returned unchanged
    except for description-length trimming and lower-casing.

    Args:
        message: Raw commit message.
        files: Optional list of changed files for scope detection.

    Returns:
        A conventional-commits compliant message string.
    """
    if not message or not message.strip():
        return "chore: update"

    message = message.strip().strip('"').strip("'")
    ctype, scope, breaking, desc, body, footers = parse_message(message)

    # Normalise type
    ctype = _normalise_type(ctype) or _infer_type(desc.lower()) or "chore"

    # Detect scope if missing
    if scope is None and files:
        scope = detect_scope(files)

    # Build header
    header = ctype
    if scope:
        header += f"({scope})"
    if breaking:
        header += "!"
    header += f": {_clean_description(desc)}"

    return _join_message(header, body, footers)


def lint_message(message: str) -> List[str]:
    """Return a list of human-readable issues with ``message``.

    Empty list means the message is fully compliant.
    """
    issues: List[str] = []
    if not message or not message.strip():
        return ["❌ empty message"]

    ctype, scope, _breaking, desc, body, footers = parse_message(message)

    if not _normalise_type(ctype):
        issues.append(f"❌ unknown type '{ctype}' (allowed: {', '.join(ALLOWED_TYPES)})")

    first_line = message.splitlines()[0]
    if len(first_line) > MAX_BODY_LINE:
        issues.append(f"❌ header line is {len(first_line)} chars (max {MAX_BODY_LINE})")

    if not desc or len(desc) < 3:
        issues.append("❌ description is too short")

    if desc and len(desc) > MAX_DESC_LENGTH:
        issues.append(f"⚠️  description is {len(desc)} chars (recommended max {MAX_DESC_LENGTH})")

    if desc and desc[0].isupper() and len(desc) > 1:
        issues.append("⚠️  description should start lowercase")

    if desc and desc.rstrip().endswith("."):
        issues.append("⚠️  description should not end with a period")

    # Body wrap check
    for line in body:
        if line and len(line) > MAX_BODY_LINE:
            issues.append(f"⚠️  body line is {len(line)} chars (max {MAX_BODY_LINE})")
            break  # one warning is enough

    return issues


def _normalise_type(type_str: str) -> Optional[str]:
    """Return a canonical lower-case type if recognised, else ``None``."""
    t = (type_str or "").strip().lower()
    return t if t in ALLOWED_TYPES else None


def _infer_type(text: str) -> Optional[str]:
    """Heuristically guess a commit type from free-text descriptions."""
    rules = [
        ("fix", ("fix", "bug", "patch", "hotfix", "repair", "resolve", "crash", "error")),
        ("feat", ("add", "implement", "introduce", "new", "support", "feature")),
        ("docs", ("doc", "readme", "comment", "documentation")),
        ("style", ("style", "format", "whitespace", "lint", "indent")),
        ("refactor", ("refactor", "restructure", "cleanup", "reorganise", "rewrite", "rename")),
        ("test", ("test", "spec", "coverage")),
        ("perf", ("perf", "performance", "optimi", "speed", "faster")),
        ("ci", ("ci", "pipeline", "workflow", "github actions", "gitlab-ci")),
        ("build", ("build", "deps", "dependency", "package", "requirements")),
        ("revert", ("revert", "rollback")),
        ("chore", ("chore", "misc", "typo", "bump")),
    ]
    for commit_type, keywords in rules:
        for kw in keywords:
            if kw in text:
                return commit_type
    return None


def _clean_description(desc: str) -> str:
    """Lower-case, strip trailing punctuation, and clamp to 72 chars."""
    desc = desc.strip().rstrip(".!?,;:")
    desc = desc.lower()
    if len(desc) > MAX_DESC_LENGTH:
        desc = desc[: MAX_DESC_LENGTH - 1].rstrip() + "…"
    return desc


def _join_message(header: str, body: List[str], footers: List[str]) -> str:
    """Combine header + body + footers per Conventional Commits spec."""
    parts = [header]
    if body:
        parts.append("")  # blank line
        parts.extend(body)
    if footers:
        parts.append("")  # blank line
        parts.extend(footers)
    return "\n".join(parts)
