"""CommitSense - AI-powered Git commit message generator."""

__version__ = "1.1.0"
__author__ = "CommitSense Contributors"
__license__ = "MIT"
