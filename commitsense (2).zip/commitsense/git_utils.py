"""Git interaction utilities with safety + smart diff handling.

All subprocess calls run from the current working directory. Each helper
returns ``None`` or empty string on failure rather than raising, so the
caller can decide how to react.
"""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

from colorama import Fore, Style


class GitError(Exception):
    """Raised when a git operation fails in an unexpected way."""


@dataclass
class DiffStat:
    """Per-file change summary parsed from a git diff."""

    file: str
    insertions: int
    deletions: int

    @property
    def total(self) -> int:
        """Return total lines changed for this file."""
        return self.insertions + self.deletions


@dataclass
class DiffInfo:
    """Everything we know about the current diff."""

    text: str
    files: List[str] = field(default_factory=list)
    stats: List[DiffStat] = field(default_factory=list)
    source: str = "empty"  # "staged" | "unstaged" | "empty"
    truncated: bool = False


def is_git_repo() -> bool:
    """Return ``True`` if the current directory is inside a git repo."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def run_git(args: List[str], timeout: int = 30) -> Tuple[int, str, str]:
    """Run a git command and return ``(returncode, stdout, stderr)``."""
    try:
        proc = subprocess.run(
            ["git", *args],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return proc.returncode, proc.stdout, proc.stderr
    except subprocess.TimeoutExpired:
        return 1, "", "git command timed out"
    except FileNotFoundError:
        return 127, "", "git is not installed"


def get_staged_diff() -> str:
    """Return the output of ``git diff --staged``."""
    code, out, _ = run_git(["diff", "--staged"])
    return out if code == 0 else ""


def get_unstaged_diff() -> str:
    """Return the output of ``git diff HEAD`` (falls back to working tree)."""
    code, out, _ = run_git(["diff", "HEAD"])
    if code == 0 and out:
        return out
    code, out, _ = run_git(["diff"])
    return out if code == 0 else ""


def get_diff() -> DiffInfo:
    """Pick the best available diff and return a :class:`DiffInfo`."""
    staged = get_staged_diff()
    if staged.strip():
        return _build_diff_info(staged, source="staged")

    unstaged = get_unstaged_diff()
    if unstaged.strip():
        return _build_diff_info(unstaged, source="unstaged")

    return DiffInfo(text="", files=[], stats=[], source="empty")


def _build_diff_info(diff_text: str, source: str) -> DiffInfo:
    files = _parse_changed_files(diff_text)
    stats = get_diff_stats(source="staged" if source == "staged" else "worktree")
    # Prefer parser-derived files if --stat failed
    return DiffInfo(text=diff_text, files=files, stats=stats, source=source)


def _parse_changed_files(diff: str) -> List[str]:
    """Extract the set of changed file paths from a unified diff."""
    files: List[str] = []
    for line in diff.splitlines():
        if not line.startswith("diff --git "):
            continue
        # Format: "diff --git a/path/to/file b/path/to/file"
        # Split on " b/" to reliably separate a/ from b/ paths,
        # even when file names contain chars like 'b' or '/'.
        try:
            _, right = line.split(" b/", 1)
            path = right  # already clean — no leading "b/" to strip
        except ValueError:
            parts = line.split()
            if len(parts) >= 4:
                path = parts[-1]
            else:
                continue
        if path not in files:
            files.append(path)
    return files


def get_diff_stats(source: str = "staged") -> List[DiffStat]:
    """Return per-file insertion/deletion counts via ``git diff --stat``."""
    args = ["diff", "--stat"] if source == "worktree" else ["diff", "--staged", "--stat"]
    code, out, _ = run_git(args)
    if code != 0 or not out.strip():
        return []

    stats: List[DiffStat] = []
    for line in out.splitlines():
        # Each stat line:  path | N +++ | M --- (and a summary at the end)
        m = re.match(r"^\s*(.+?)\s+\|\s+(\d+)\s+\+*\s*(\d+)?\s*-*\s*$", line)
        if not m:
            continue
        path = m.group(1).strip()
        ins = int(m.group(2) or 0)
        dels = int(m.group(3) or 0)
        stats.append(DiffStat(file=path, insertions=ins, deletions=dels))
    return stats


def smart_truncate_diff(diff: str, max_chars: int = 8000) -> str:
    """Intelligently truncate a huge diff to keep prompts small.

    Keeps every file's header (``diff --git``, ``index``, ``---``, ``+++``)
    plus a budgeted slice of hunks. Always emits every file's header so
    the LLM knows which files were touched, even when hunks are dropped.
    """
    if len(diff) <= max_chars:
        return diff

    lines = diff.splitlines()
    file_starts = [i for i, ln in enumerate(lines) if ln.startswith("diff --git ")]
    if not file_starts:
        # No headers — just slice
        return diff[: max_chars - 50] + "\n… [diff truncated]"

    file_count = len(file_starts)
    # Reserve a header slice per file so all file names survive
    header_lines_per_file = 4  # diff, index, ---, +++
    per_file_budget = max(
        header_lines_per_file + 10,
        (max_chars // file_count) // 80,  # ~80 chars/line
    )

    out: List[str] = []
    for idx, start in enumerate(file_starts):
        end = file_starts[idx + 1] if idx + 1 < file_count else len(lines)
        block = lines[start:end]

        # Always keep the first N header lines
        out.extend(block[:header_lines_per_file])

        body = block[header_lines_per_file:]
        if len(body) > per_file_budget:
            kept = body[:per_file_budget]
            out.extend(kept)
            out.append(f"… [{len(body) - per_file_budget} more lines elided]")
        else:
            out.extend(body)

    result = "\n".join(out)
    if len(result) > max_chars:
        result = result[: max_chars - 50] + "\n… [diff truncated]"
    return result


def stage_all() -> bool:
    """Run ``git add -A``. Returns ``True`` on success."""
    code, _, err = run_git(["add", "-A"])
    if code != 0:
        print(f"{Fore.RED}❌ Failed to stage files: {err.strip()}{Style.RESET_ALL}")
        return False
    return True


def commit_changes(message: str, amend: bool = False) -> bool:
    """Create (or amend) a commit with ``message`` as the commit message."""
    if not message.strip():
        print(f"{Fore.RED}❌ Empty commit message — aborting.{Style.RESET_ALL}")
        return False

    args = ["commit", "-m", message]
    if amend:
        args.append("--amend")
    code, out, err = run_git(args)
    if code != 0:
        print(f"{Fore.RED}❌ git commit failed: {err.strip() or out.strip()}{Style.RESET_ALL}")
        return False
    print(f"{Fore.GREEN}✅ {'Amended' if amend else 'Committed'} successfully!{Style.RESET_ALL}")
    if out.strip():
        print(out.strip())
    return True


def get_repo_root() -> Optional[Path]:
    """Return the absolute path to the repository root, if any."""
    code, out, _ = run_git(["rev-parse", "--show-toplevel"])
    if code == 0 and out.strip():
        return Path(out.strip()).resolve()
    return None


def install_git_hook(hook_command: str = "commitsense --yes") -> bool:
    """Install a ``prepare-commit-msg`` hook that pre-fills the message.

    Args:
        hook_command: Shell command to invoke CommitSense (override if
            CommitSense isn't on PATH, e.g. ``python -m commitsense --yes``).

    Returns:
        ``True`` if the hook was installed successfully.
    """
    root = get_repo_root()
    if root is None:
        print(f"{Fore.RED}❌ Not a git repository.{Style.RESET_ALL}")
        return False

    hooks_dir = root / ".git" / "hooks"
    try:
        hooks_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        print(f"{Fore.RED}❌ Cannot create hooks dir: {exc}{Style.RESET_ALL}")
        return False

    hook_path = hooks_dir / "prepare-commit-msg"
    script = (
        "#!/usr/bin/env sh\n"
        "# Installed by CommitSense — auto-fills commit message via AI.\n"
        "# Bypass with: git commit --no-verify\n"
        f"{hook_command} \"$1\" || true\n"
    )
    try:
        hook_path.write_text(script, encoding="utf-8")
        hook_path.chmod(0o755)
    except OSError as exc:
        print(f"{Fore.RED}❌ Cannot write hook: {exc}{Style.RESET_ALL}")
        return False

    print(f"{Fore.GREEN}✅ Installed git hook at {hook_path}{Style.RESET_ALL}")
    print(
        f"{Fore.CYAN}   It will auto-run `commitsense` on every `git commit`.\n"
        f"   Bypass with: git commit --no-verify{Style.RESET_ALL}"
    )
    return True
