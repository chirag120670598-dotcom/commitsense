"""Command-line interface entry point for CommitSense.

Wires together git introspection, the Ollama AI engine, formatting,
spinner UX, caching, and the interactive user menu.
"""

from __future__ import annotations

import os
import sys
import threading
import time
from typing import Optional

import click
import inquirer
import pyperclip
from colorama import Fore, Style
from colorama import init as colorama_init

from . import __version__, cache
from .ai_engine import (
    OllamaInvalidResponse,
    OllamaModelMissing,
    OllamaUnavailable,
    friendly_error,
    generate,
)
from .config import interactive_config, load_config
from .formatter import enforce_conventional, lint_message
from .git_utils import (
    DiffInfo,
    commit_changes,
    get_diff,
    install_git_hook,
    is_git_repo,
    smart_truncate_diff,
)
from .git_utils import stage_all as do_stage_all


# ---------- Global state ----------
class _State:
    no_color: bool = False
    verbose: bool = False


_state = _State()


# ---------- Color helpers ----------
def _c(color: str, text: str) -> str:
    """Return coloured text or plain text if --no-color is set."""
    if _state.no_color:
        return text
    return f"{color}{text}{Style.RESET_ALL}"


# ---------- Spinner ----------
class Spinner:
    """Lightweight animated spinner for blocking calls."""

    FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

    def __init__(self, message: str) -> None:
        self.message = message
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def __enter__(self) -> Spinner:
        if _state.no_color or not sys.stderr.isatty():
            click.echo(self.message, err=True)
            return self
        self._thread = threading.Thread(target=self._spin, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *_: object) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join()
        if not _state.no_color and sys.stderr.isatty():
            click.echo("\r" + " " * (len(self.message) + 4) + "\r", err=True, nl=False)

    def _spin(self) -> None:
        i = 0
        while not self._stop.is_set():
            frame = self.FRAMES[i % len(self.FRAMES)]
            click.echo(f"\r  {frame} {self.message}", err=True, nl=False)
            time.sleep(0.08)
            i += 1


# ---------- Display ----------
def _print_banner() -> None:
    click.echo(
        _c(
            Fore.CYAN,
            "\n╔════════════════════════════════════════╗\n"
            f"║   🧠 CommitSense v{__version__:<24}║\n"
            "║   AI-powered Conventional Commits      ║\n"
            "╚════════════════════════════════════════╝\n",
        )
    )


def _print_results(
    commit_msg: str,
    pr_title: str,
    pr_description: str,
) -> None:
    """Pretty-print the AI results in coloured blocks."""
    click.echo(_c(Fore.GREEN, "✅ Suggested commit message:"))
    for line in commit_msg.splitlines():
        click.echo(f"   {_c(Fore.GREEN, line)}")
    click.echo("")

    click.echo(_c(Fore.BLUE, "📝 PR Title:"))
    click.echo(f"   {_c(Fore.BLUE, pr_title)}\n")

    click.echo(_c(Fore.YELLOW, "📄 PR Description (preview):"))
    preview = pr_description if len(pr_description) <= 400 else pr_description[:400] + "…"
    for line in preview.splitlines():
        click.echo(f"   {_c(Fore.YELLOW, line)}")
    if len(pr_description) > 400:
        click.echo(
            _c(
                Fore.YELLOW,
                "   …(truncated — choose 'Save PR description' to write the full text)",
            )
        )
    click.echo("")


def _print_diff_summary(info: DiffInfo) -> None:
    """Print ``Found changes in N files (source)`` plus a one-line stat."""
    click.echo(
        _c(
            Fore.CYAN,
            f"🔍 Found changes in {len(info.files)} file(s) ({info.source}).",
        )
    )
    if info.stats:
        total_ins = sum(s.insertions for s in info.stats)
        total_del = sum(s.deletions for s in info.stats)
        click.echo(
            _c(
                Fore.CYAN,
                f"   {Fore.GREEN}+{total_ins}{Fore.CYAN} / {Fore.RED}-{total_del}"
                f"{Fore.CYAN} across {len(info.stats)} files",
            )
        )
        shown = ", ".join(f"{s.file} (+{s.insertions} -{s.deletions})" for s in info.stats[:5])
        extra = f" (+{len(info.stats) - 5} more)" if len(info.stats) > 5 else ""
        click.echo(_c(Fore.CYAN, f"   {shown}{extra}"))
    elif info.files:
        shown = ", ".join(info.files[:5])
        extra = f" (+{len(info.files) - 5} more)" if len(info.files) > 5 else ""
        click.echo(_c(Fore.CYAN, f"   {shown}{extra}"))


# ---------- Menu ----------
def _ask_menu(commit_msg: str) -> str:
    """Show the interactive inquirer menu and return the chosen action key."""
    questions = [
        inquirer.List(
            "choice",
            message="What do you want to do?",
            choices=[
                ("✅ Commit with this message", "commit"),
                ("✏️  Edit message manually then commit", "edit"),
                ("🔄 Regenerate (try again)", "regenerate"),
                ("📋 Copy message to clipboard", "copy"),
                ("💾 Save PR description to pr_description.md", "save"),
                ("❌ Cancel", "cancel"),
            ],
            carousel=True,
        ),
    ]
    answer = inquirer.prompt(questions)
    if not answer:
        return "cancel"
    return answer.get("choice", "cancel")


# ---------- Flow ----------
def _run_flow(
    model: str,
    language: str,
    auto_stage: bool,
    amend: bool,
    yes: bool,
    dry_run: bool,
    no_cache: bool,
) -> None:
    """Execute the full CommitSense flow end-to-end."""
    if not is_git_repo():
        click.echo(
            _c(
                Fore.RED,
                "❌ Not a git repository. Run commitsense from inside a git project.",
            )
        )
        sys.exit(1)

    if auto_stage:
        click.echo(_c(Fore.CYAN, "📦 Auto-staging all changes…"))
        if not do_stage_all():
            sys.exit(1)

    attempt = 0
    while True:
        attempt += 1
        info = get_diff()
        if not info.text.strip():
            click.echo(
                _c(Fore.RED, "❌ Nothing to commit. Stage your files first.")
            )
            sys.exit(1)

        _print_diff_summary(info)

        if _state.verbose:
            click.echo(_c(Fore.MAGENTA, f"   model={model} lang={language}"))

        diff_for_ai = smart_truncate_diff(info.text)
        if len(diff_for_ai) < len(info.text):
            click.echo(
                _c(
                    Fore.YELLOW,
                    f"   ✂️  truncated diff from {len(info.text)} → "
                    f"{len(diff_for_ai)} chars",
                )
            )

        click.echo(_c(Fore.CYAN, f"🤖 Asking {model} to summarise the diff…"))
        with Spinner(f"Ollama is thinking… (attempt {attempt})"):
            try:
                result = generate(
                    diff=diff_for_ai,
                    model=model,
                    language=language,
                    use_cache=not no_cache,
                )
            except (OllamaUnavailable, OllamaModelMissing, OllamaInvalidResponse) as exc:
                click.echo(friendly_error(exc))
                sys.exit(1)
            except Exception as exc:  # pragma: no cover - last-resort guard
                click.echo(friendly_error(exc))
                sys.exit(1)

        # Enforce Conventional Commits
        result["commit_message"] = enforce_conventional(
            result["commit_message"], info.files
        )

        if _state.verbose:
            click.echo(_c(Fore.MAGENTA, f"   cached={'no' if no_cache else 'yes'}"))

        _print_results(
            result["commit_message"],
            result["pr_title"],
            result["pr_description"],
        )

        # --- Decide what to do next ---
        if dry_run:
            click.echo(_c(Fore.YELLOW, "🧪 --dry-run: nothing committed."))
            sys.exit(0)

        if yes:
            choice = "commit"
        else:
            choice = _ask_menu(result["commit_message"])

        if choice == "commit":
            if commit_changes(result["commit_message"], amend=amend):
                sys.exit(0)
            sys.exit(1)

        if choice == "edit":
            edited = click.edit(
                result["commit_message"],
                editor=os.environ.get("EDITOR"),
                require_save=False,
            )
            if edited is None or not edited.strip():
                click.echo(
                    _c(Fore.YELLOW, "⚠️  Edit cancelled or empty. Nothing committed.")
                )
                sys.exit(0)
            edited = enforce_conventional(edited.strip(), info.files)
            if commit_changes(edited, amend=amend):
                sys.exit(0)
            sys.exit(1)

        if choice == "regenerate":
            click.echo(_c(Fore.CYAN, "\n🔄 Regenerating…\n"))
            continue

        if choice == "copy":
            try:
                pyperclip.copy(result["commit_message"])
                click.echo(_c(Fore.GREEN, "📋 Copied to clipboard!"))
            except pyperclip.PyperclipException as exc:
                click.echo(_c(Fore.RED, f"❌ Clipboard unavailable: {exc}"))
            sys.exit(0)

        if choice == "save":
            try:
                with open("pr_description.md", "w", encoding="utf-8") as f:
                    f.write(f"# {result['pr_title']}\n\n")
                    f.write(result["pr_description"] or "")
                    if not result["pr_description"].endswith("\n"):
                        f.write("\n")
                click.echo(_c(Fore.GREEN, "💾 Saved to pr_description.md"))
            except OSError as exc:
                click.echo(_c(Fore.RED, f"❌ Failed to write file: {exc}"))
            sys.exit(0)

        click.echo(_c(Fore.YELLOW, "👋 Cancelled. Nothing committed."))
        sys.exit(0)


# ---------- Click CLI ----------
@click.command(
    help=(
        "CommitSense — AI-powered Git commit messages using local Ollama.\n\n"
        "Run from inside any git repository with staged or unstaged changes."
    ),
    context_settings={"help_option_names": ["-h", "--help"]},
)
@click.option("--config", "run_config", is_flag=True, help="Open the interactive config editor.")
@click.option("--model", "-m", default=None, help="Ollama model to use (overrides config).")
@click.option("--lang", "--language", "language", default=None,
              help="Language for commit messages (english, hindi, spanish, french, german).")
@click.option("--stage-all", "stage_all_flag", is_flag=True, help="Run `git add -A` before generating the message.")
@click.option("--amend", is_flag=True, help="Amend the previous commit instead of creating a new one.")
@click.option("--yes", "-y", is_flag=True, help="Skip the interactive menu and commit immediately.")
@click.option("--dry-run", is_flag=True, help="Show the suggested message but do not commit.")
@click.option("--no-cache", is_flag=True, help="Bypass the response cache for this run.")
@click.option("--no-color", is_flag=True, help="Disable ANSI colours (for piping/CI).")
@click.option("--verbose", "-v", is_flag=True, help="Show extra debug info.")
@click.option("--check", "check_message", default=None,
              help="Lint an existing commit message and exit (no AI call).")
@click.option("--clear-cache", is_flag=True, help="Wipe the on-disk response cache and exit.")
@click.option("--install-hook", is_flag=True,
              help="Install a prepare-commit-msg git hook that auto-fills messages.")
@click.version_option(__version__, prog_name="commitsense")
def main(
    run_config: bool,
    model: Optional[str],
    language: Optional[str],
    stage_all_flag: bool,
    amend: bool,
    yes: bool,
    dry_run: bool,
    no_cache: bool,
    no_color: bool,
    verbose: bool,
    check_message: Optional[str],
    clear_cache: bool,
    install_hook: bool,
) -> None:
    """CLI entry point."""
    _state.no_color = no_color
    _state.verbose = verbose
    if no_color:
        colorama_init(strip=True, autoreset=True)
    else:
        colorama_init(autoreset=True)

    # --- Sub-command style flags (handled before main flow) ---
    if check_message is not None:
        issues = lint_message(check_message)
        if not issues:
            click.echo(_c(Fore.GREEN, f"✅ '{check_message}' is fully compliant."))
            sys.exit(0)
        click.echo(_c(Fore.YELLOW, "Commit message has issues:"))
        for issue in issues:
            click.echo(f"   {issue}")
        sys.exit(1)

    if clear_cache:
        n = cache.clear()
        click.echo(_c(Fore.GREEN, f"🧹 Cleared {n} cached entries."))
        sys.exit(0)

    if install_hook:
        ok = install_git_hook()
        sys.exit(0 if ok else 1)

    if run_config:
        interactive_config()
        sys.exit(0)

    cfg = load_config()
    chosen_model = (model or cfg.get("model") or "llama3").strip()
    chosen_language = (language or cfg.get("language") or "english").strip().lower()
    auto_stage = stage_all_flag or bool(cfg.get("auto_stage_all", False))

    _print_banner()
    _run_flow(
        model=chosen_model,
        language=chosen_language,
        auto_stage=auto_stage,
        amend=amend,
        yes=yes,
        dry_run=dry_run,
        no_cache=no_cache,
    )


if __name__ == "__main__":
    main()
