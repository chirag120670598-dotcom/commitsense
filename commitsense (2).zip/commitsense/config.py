"""Configuration management for CommitSense.

Handles loading, saving, and editing of user config stored at
``~/.commitsense/config.json``.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

import click
from colorama import Fore, Style

CONFIG_DIR: Path = Path.home() / ".commitsense"
CONFIG_FILE: Path = CONFIG_DIR / "config.json"

DEFAULT_CONFIG: Dict[str, Any] = {
    "model": "llama3",
    "auto_stage_all": False,
    "commit_style": "conventional",
    "language": "english",
}

VALID_LANGUAGES = ("english", "hindi", "spanish", "french", "german")
VALID_STYLES = ("conventional", "freeform")


def ensure_config_exists() -> None:
    """Create the config directory and file with defaults if missing.

    Uses an internal helper that does *not* call back into
    ``ensure_config_exists`` to avoid infinite recursion on permission errors.
    """
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    except OSError:
        return  # If we cannot create the dir, every save will also fail.
    if not CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(DEFAULT_CONFIG, f, indent=2)
        except OSError:
            pass


def load_config() -> Dict[str, Any]:
    """Load the user config, falling back to defaults on error.

    Returns:
        Dict[str, Any]: The merged configuration dictionary.
    """
    ensure_config_exists()
    try:
        with open(CONFIG_FILE, encoding="utf-8") as f:
            user_cfg: Dict[str, Any] = json.load(f)
    except (json.JSONDecodeError, OSError):
        # Corrupt or unreadable config - reset to defaults
        save_config(DEFAULT_CONFIG.copy())
        return DEFAULT_CONFIG.copy()

    # Merge with defaults so new keys are always present
    merged = DEFAULT_CONFIG.copy()
    merged.update(user_cfg)
    return merged


def save_config(cfg: Dict[str, Any]) -> None:
    """Persist the configuration dictionary to disk.

    Args:
        cfg: Configuration dictionary to save.
    """
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
    except OSError:
        pass


def interactive_config() -> None:
    """Run an interactive editor to update the user's config."""
    cfg = load_config()

    click.echo(f"\n{Fore.CYAN}⚙️  CommitSense Configuration{Style.RESET_ALL}")
    click.echo(f"{Fore.CYAN}Config file: {CONFIG_FILE}{Style.RESET_ALL}\n")

    # Model name
    new_model = click.prompt(
        f"{Fore.GREEN}Ollama model name{Style.RESET_ALL}",
        default=cfg.get("model", "llama3"),
    )
    cfg["model"] = new_model.strip() or "llama3"

    # Auto-stage
    auto = click.confirm(
        f"{Fore.GREEN}Auto-stage all changes before commit?{Style.RESET_ALL}",
        default=cfg.get("auto_stage_all", False),
    )
    cfg["auto_stage_all"] = auto

    # Commit style
    style_choice = click.prompt(
        f"{Fore.GREEN}Commit style{Style.RESET_ALL}",
        type=click.Choice(VALID_STYLES, case_sensitive=False),
        default=cfg.get("commit_style", "conventional"),
        show_choices=True,
    )
    cfg["commit_style"] = style_choice.lower()

    # Language
    lang_choice = click.prompt(
        f"{Fore.GREEN}Language for commit messages{Style.RESET_ALL}",
        type=click.Choice(VALID_LANGUAGES, case_sensitive=False),
        default=cfg.get("language", "english"),
        show_choices=True,
    )
    cfg["language"] = lang_choice.lower()

    save_config(cfg)
    click.echo(f"\n{Fore.GREEN}✅ Configuration saved!{Style.RESET_ALL}\n")
