"""Ollama API client.

Wraps ``POST http://localhost:11434/api/generate`` with friendlier errors,
strict-JSON parsing with retry, and a cache-aware top-level helper.
"""

from __future__ import annotations

import json
import re
import time
from typing import Any, Dict, Optional

import requests
from colorama import Fore, Style

from . import cache

DEFAULT_HOST = "http://localhost:11434"
DEFAULT_TIMEOUT = 120  # seconds


class OllamaUnavailable(Exception):
    """Raised when the Ollama server cannot be reached."""


class OllamaModelMissing(Exception):
    """Raised when the requested model is not pulled in Ollama."""


class OllamaInvalidResponse(Exception):
    """Raised when the model returns a response that cannot be parsed."""


# Module-level: cache the liveness check for 30 s to avoid hot-loop probes
_HEALTH_CACHE: Dict[str, float] = {}
_HEALTH_TTL = 30.0


def _build_prompt(diff: str, language: str) -> str:
    """Construct the prompt that instructs Ollama to return strict JSON."""
    lang_line = ""
    if language and language.lower() not in {"english", "en"}:
        lang_line = (
            f"\nIMPORTANT: Write the commit_message, pr_title, and pr_description "
            f"in {language.capitalize()}."
        )

    return (
        "You are an expert senior software engineer who writes perfect "
        "Conventional Commit messages and pull-request descriptions.\n\n"
        "Given the following git diff, respond with ONLY a single JSON object "
        "(no markdown fences, no commentary, no extra text) using this exact "
        "schema:\n"
        "{\n"
        '  "commit_message": "type(scope): short imperative description",\n'
        '  "pr_title": "A clear, human-readable PR title",\n'
        '  "pr_description": "## What changed\\n...\\n## Why\\n...\\n'
        '## How to test\\n..."\n'
        "}\n\n"
        "Rules:\n"
        "- type must be one of: feat, fix, docs, style, refactor, test, chore, "
        "perf, ci, build, revert\n"
        "- scope should be the main module/file area changed (omit if unclear)\n"
        "- commit_message description must be lowercase, max 72 chars, no "
        "trailing period\n"
        "- If the diff contains a breaking change, append `!` before the colon "
        "and add a `BREAKING CHANGE: <reason>` footer\n"
        "- pr_description must contain three sections: What changed / Why / "
        "How to test\n"
        "- Mention issue references like Closes #123 if visible in the diff\n"
        f"{lang_line}\n\n"
        "GIT DIFF:\n"
        "```\n"
        f"{diff}\n"
        "```\n"
    )


def _extract_json(text: str) -> Optional[Dict[str, Any]]:
    """Try several strategies to extract a JSON object from ``text``."""
    text = text.strip()

    # 1) Direct parse
    try:
        data = json.loads(text)
        if isinstance(data, dict):
            return data
    except json.JSONDecodeError:
        pass

    # 2) Strip ```json ... ``` fences
    fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if fenced:
        try:
            data = json.loads(fenced.group(1))
            if isinstance(data, dict):
                return data
        except json.JSONDecodeError:
            pass

    # 3) First {...} block in the response
    brace_match = re.search(r"\{.*\}", text, re.DOTALL)
    if brace_match:
        try:
            data = json.loads(brace_match.group(0))
            if isinstance(data, dict):
                return data
        except json.JSONDecodeError:
            pass

    return None


def is_ollama_running(host: str = DEFAULT_HOST, use_cache: bool = True) -> bool:
    """Return ``True`` if the Ollama server responds to a root GET.

    Caches the answer for :data:`_HEALTH_TTL` seconds.
    """
    now = time.time()
    if use_cache and host in _HEALTH_CACHE and now - _HEALTH_CACHE[host] < _HEALTH_TTL:
        return True
    try:
        r = requests.get(host, timeout=3)
        ok = r.status_code == 200
    except requests.RequestException:
        ok = False
    if ok:
        _HEALTH_CACHE[host] = now
    return ok


def _post_generate(url: str, payload: Dict[str, Any], timeout: int) -> requests.Response:
    """POST to /api/generate, surfacing low-level errors as domain errors."""
    try:
        return requests.post(url, json=payload, timeout=timeout)
    except requests.RequestException as exc:
        raise OllamaUnavailable(f"Could not reach Ollama: {exc}") from exc


def generate(
    diff: str,
    model: str = "llama3",
    language: str = "english",
    host: str = DEFAULT_HOST,
    timeout: int = DEFAULT_TIMEOUT,
    use_cache: bool = True,
) -> Dict[str, Any]:
    """Call Ollama and return a parsed commit/PR payload.

    Args:
        diff: The git diff text to send as context.
        model: Name of the Ollama model to use.
        language: Output language hint ("english", "hindi", ...).
        host: Ollama server base URL.
        timeout: HTTP timeout in seconds.
        use_cache: When ``True``, reuse cached responses for identical inputs.

    Returns:
        Dict with keys ``commit_message``, ``pr_title``, ``pr_description``.

    Raises:
        OllamaUnavailable: If the server is unreachable.
        OllamaModelMissing: If the model is not available locally.
        OllamaInvalidResponse: If the response cannot be parsed as JSON.
    """
    cache_key = cache.make_key(diff, model, language)
    if use_cache:
        cached = cache.get(cache_key)
        if cached is not None:
            return cached

    if not is_ollama_running(host):
        raise OllamaUnavailable(
            f"Ollama not running at {host}. Start it with: ollama serve"
        )

    url = f"{host}/api/generate"
    base_payload = {
        "model": model,
        "prompt": _build_prompt(diff, language),
        "stream": False,
        "options": {"temperature": 0.2},
    }

    response = _post_generate(url, base_payload, timeout)

    if response.status_code == 404:
        raise OllamaModelMissing(
            f"Model '{model}' not found. Run: ollama pull {model}"
        )
    if response.status_code != 200:
        raise OllamaUnavailable(
            f"Ollama returned HTTP {response.status_code}: {response.text[:200]}"
        )

    try:
        body = response.json()
        raw_text: str = body.get("response", "")
    except ValueError as exc:
        raise OllamaInvalidResponse("Ollama returned non-JSON envelope.") from exc

    parsed = _extract_json(raw_text)
    if not parsed:
        # Retry once with a stricter prompt
        retry_payload = dict(base_payload)
        retry_payload["prompt"] = (
            "Respond with ONLY a JSON object, nothing else.\n\n" + base_payload["prompt"]
        )
        r2 = _post_generate(url, retry_payload, timeout)
        if r2.status_code == 200:
            try:
                parsed = _extract_json(r2.json().get("response", ""))
            except ValueError:
                parsed = None

    if not parsed:
        # Final fallback: derive a commit message from raw text
        fallback_msg = raw_text.strip().splitlines()[0] if raw_text.strip() else ""
        result = {
            "commit_message": fallback_msg or "chore: update",
            "pr_title": fallback_msg or "Update",
            "pr_description": raw_text or "",
        }
    else:
        result = {
            "commit_message": str(parsed.get("commit_message", "")).strip() or "chore: update",
            "pr_title": str(parsed.get("pr_title", "")).strip()
            or parsed.get("commit_message", "Update"),
            "pr_description": str(parsed.get("pr_description", "")).strip(),
        }

    if use_cache:
        cache.set_(cache_key, result)

    return result


def friendly_error(exc: Exception) -> str:
    """Return a user-facing error message for a known Ollama exception."""
    if isinstance(exc, OllamaUnavailable):
        return (
            f"{Fore.RED}❌ {exc}\n"
            f"   Start it with: ollama serve{Style.RESET_ALL}"
        )
    if isinstance(exc, OllamaModelMissing):
        return f"{Fore.RED}❌ {exc}{Style.RESET_ALL}"
    if isinstance(exc, OllamaInvalidResponse):
        return (
            f"{Fore.RED}❌ Could not parse Ollama response as JSON. "
            f"The model may need a different prompt.{Style.RESET_ALL}"
        )
    return f"{Fore.RED}❌ Unexpected error: {exc}{Style.RESET_ALL}"
