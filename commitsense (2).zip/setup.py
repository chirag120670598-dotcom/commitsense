"""Minimal setup.py shim.

The full project metadata lives in ``pyproject.toml``. This file exists
only for very old pip versions that don't yet read PEP 621 metadata.
"""

from setuptools import setup

setup()